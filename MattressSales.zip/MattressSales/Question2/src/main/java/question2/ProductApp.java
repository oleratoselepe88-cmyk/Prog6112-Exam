package question2;

import javax.swing.*;
import java.awt.*;

public class ProductApp extends JFrame {

    private final JTextField txtCustomer = new JTextField(20);
    private final JComboBox<String> cmbProduct = new JComboBox<>(new String[]{
        "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"
    });
    private final JTextField txtPrice = new JTextField(20);
    private final JButton btnProcess = new JButton("PROCESS");

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 10, 15));
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        add(new JLabel("Customer Name:"));
        add(txtCustomer);
        add(new JLabel("Select Product:"));
        add(cmbProduct);
        add(new JLabel("Enter Price:"));
        add(txtPrice);
        add(new JLabel(""));
        add(btnProcess);

        btnProcess.addActionListener(e -> process());

        pack();
        setLocationRelativeTo(null);
    }

    private void process() {
        String customer = txtCustomer.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();
        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
            return;
        }

        double vat = price * 0.15;
        double commission = price * 0.05;
        double total = price + vat + commission;

        JOptionPane.showMessageDialog(this,
                "Customer Name: " + customer + "\n"
                + "Product: " + product + "\n"
                + "VAT: R " + vat + "\n"
                + "COMMISSION: R " + commission + "\n"
                + "TOTAL: R " + total);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
